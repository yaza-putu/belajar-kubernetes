# Kubernetes architecture

Covered in this video: https://www.youtube.com/watch?v=68yKslO2Pz0
