# Set up Wordpress

Covered in a video; use instructions in projects/wordpress/Project-Instructions.md
